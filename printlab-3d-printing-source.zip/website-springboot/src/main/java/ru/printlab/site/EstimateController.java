package ru.printlab.site;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class EstimateController {
    private static final Map<String, BigDecimal> PRICE_PER_GRAM = Map.of(
            "PLA", new BigDecimal("0.18"),
            "PETG", new BigDecimal("0.22"),
            "ABS", new BigDecimal("0.24"),
            "TPU", new BigDecimal("0.35")
    );
    private static final BigDecimal SETUP_FEE = new BigDecimal("5.00");
    private static final BigDecimal MINIMUM_PRICE = new BigDecimal("8.00");

    @PostMapping("/estimate")
    public ResponseEntity<Map<String, Object>> estimate(@RequestBody EstimateRequest request) {
        if (request == null || request.material() == null || request.grams() == null || request.quantity() == null) {
            return badRequest("Заполните все поля калькулятора.");
        }

        String material = request.material().trim().toUpperCase();
        BigDecimal rate = PRICE_PER_GRAM.get(material);
        if (rate == null) {
            return badRequest("Выберите материал из списка.");
        }
        if (request.grams() < 1 || request.grams() > 5000) {
            return badRequest("Вес должен быть от 1 до 5000 г.");
        }
        if (request.quantity() < 1 || request.quantity() > 100) {
            return badRequest("Количество должно быть от 1 до 100.");
        }

        BigDecimal perItem = SETUP_FEE.add(rate.multiply(BigDecimal.valueOf(request.grams())))
                .max(MINIMUM_PRICE);
        BigDecimal discount = request.quantity() >= 10
                ? new BigDecimal("0.80")
                : request.quantity() >= 3 ? new BigDecimal("0.90") : BigDecimal.ONE;
        BigDecimal total = perItem.multiply(BigDecimal.valueOf(request.quantity()))
                .multiply(discount).setScale(2, RoundingMode.HALF_UP);

        return ResponseEntity.ok(Map.of(
                "material", material,
                "grams", request.grams(),
                "quantity", request.quantity(),
                "unitPrice", perItem.setScale(2, RoundingMode.HALF_UP),
                "total", total,
                "discountPercent", discount.equals(BigDecimal.ONE) ? 0 : discount.equals(new BigDecimal("0.90")) ? 10 : 20
        ));
    }

    private ResponseEntity<Map<String, Object>> badRequest(String message) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", message));
    }

    public record EstimateRequest(String material, Integer grams, Integer quantity) {}
}
