from decimal import Decimal, ROUND_HALF_UP

from flask import Flask, jsonify, render_template, request

app = Flask(__name__)

PRICE_PER_GRAM = {
    "PLA": Decimal("0.18"),
    "PETG": Decimal("0.22"),
    "ABS": Decimal("0.24"),
    "TPU": Decimal("0.35"),
}
SETUP_FEE = Decimal("5.00")
MINIMUM_PRICE = Decimal("8.00")


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/api/estimate")
def estimate():
    payload = request.get_json(silent=True) or {}
    material = str(payload.get("material", "")).strip().upper()

    try:
        grams = int(payload.get("grams"))
        quantity = int(payload.get("quantity"))
    except (TypeError, ValueError):
        return jsonify(error="Заполните все поля калькулятора числами."), 400

    if material not in PRICE_PER_GRAM:
        return jsonify(error="Выберите материал из списка."), 400
    if not 1 <= grams <= 5000:
        return jsonify(error="Вес должен быть от 1 до 5000 г."), 400
    if not 1 <= quantity <= 100:
        return jsonify(error="Количество должно быть от 1 до 100."), 400

    unit_price = max(MINIMUM_PRICE, SETUP_FEE + PRICE_PER_GRAM[material] * grams)
    discount = Decimal("0.80") if quantity >= 10 else Decimal("0.90") if quantity >= 3 else Decimal("1.00")
    total = (unit_price * quantity * discount).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    return jsonify(
        material=material,
        grams=grams,
        quantity=quantity,
        unitPrice=float(unit_price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)),
        total=float(total),
        discountPercent=0 if discount == Decimal("1.00") else 10 if discount == Decimal("0.90") else 20,
    )


if __name__ == "__main__":
    app.run(debug=True)
