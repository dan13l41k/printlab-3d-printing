const form = document.querySelector('#estimate-form');
const message = document.querySelector('#estimate-message');
const result = document.querySelector('#estimate-result');

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  result.hidden = true;
  message.classList.remove('is-error');
  message.textContent = 'Считаем стоимость…';

  const payload = {
    material: form.elements.material.value,
    grams: Number(form.elements.grams.value),
    quantity: Number(form.elements.quantity.value),
  };

  try {
    const response = await fetch('/api/estimate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Не удалось рассчитать цену.');

    const money = new Intl.NumberFormat('ru-RU', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.querySelector('#estimate-total').textContent = `${money.format(data.total)} ₾`;
    document.querySelector('#estimate-detail').textContent = `${data.quantity} шт. · ${data.material} · ${data.grams} г на деталь${data.discountPercent ? ` · скидка ${data.discountPercent}%` : ''}`;
    result.hidden = false;
    message.textContent = 'Готово — это предварительная оценка.';
  } catch (error) {
    message.textContent = error.message || 'Не удалось связаться с сервером. Попробуйте ещё раз.';
    message.classList.add('is-error');
  }
});
